package database


import {

	"github.com/jinzhu/gorm"

	"github.com/lathifshaik/go_projec"

}

func GetBook(db *gorm.DB) ([]modles.Book,error) {

	books := []modles.Book{}
	query := db.Select("books.*")
	err := query.Find(&books).Error
	if err != nil {
		return nil, err
	}

	return books,nil
}


func GetBookID(db *gorm.DB ,id string) ([]modles.Book,error){
	return modles.Book{},nil
}

func DeleteBookID(db *gorm.DB ,id string) ([]modles.Book,error){
	return modles.Book{},nil

}

func UpdateBookID(db *gorm.DB ,id string) ([]modles.Book,error){
	return modles.Book{},nil

}